StudySpark
=========
A simple student dashboard website.

Open index.html in a browser.
No installation or internet connection is required.

Features:
- Dashboard
- Subject notes
- Practice/mock tests
- Focus timer
- Weekly timetable
- Progress tracker
- Revision planner
- Responsive mobile layout
